
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Unsri Lapor</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/unsri.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Layanan<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="kritik.php">kritik dan saran</a></li>
                    <li><a href="lapor.php">Lapor Fasilitas</a></li>
                  </ul>
                 <li class="active"><a href="beasiswa.php">Beasiswa</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCkLQJRQX9g7fT_E3zD6eCdw">Youtube</a></li>
              </ul>
            </div>
        </div>
</div>


    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->
<br>
    <div class="container marketing">

<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
          Beasiswa DataPrint
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
      <div class="panel-body">
        Program beasiswa DataPrint telah memasuki tahun kesembilan. Setelah sukses mengadakan program beasiswa di tahun 2011 hingga 2018, maka DataPrint kembali membuat program beasiswa bagi penggunanya yang berstatus pelajar dan mahasiswa.  Untuk mengetahui varian produk DataPrint, kamu bisa mengunjungi website resmi DataPrint di  www.dataprint.co.id .
        <br><br>Di tahun 2019 sebanyak 450 beasiswa akan diberikan bagi pendaftar yang terseleksi. Program beasiswa dibagi dalam dua periode. Tidak ada sistem kuota berdasarkan daerah dan atau sekolah/perguruan tinggi. Hal ini bertujuan agar beasiswa dapat diterima secara merata bagi seluruh pengguna DataPrint.  Beasiswa terbagi dalam tiga nominal yaitu Rp 400 ribu, Rp 600 ribu dan Rp 1 juta. Dana beasiswa akan diberikan satu kali bagi peserta yang lolos penilaian. Aspek penilaian berdasarkan dari essay, prestasi dan keaktifan peserta.
        <br>
<br>
<a href="https://himsiunsri.org/pendaftaran-beasiswa-mizan-2019/">klik disini</a> untuk info lebih lanjut

      </div>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
          Beasiswa Mizan
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse">
      <div class="panel-body">Program Beasiswa Mizan kembali hadir pada tahun 2019 ini untuk menyokong semangat kreatifitas dan kualitas berkarya para calon cendikia Indonesia. Mizan percaya bahwa program Beasiswa Mizan dapat menjadi pemantik dari ide dan gagasan yang terus berkobar dikalangan mahasiswa. Oleh karena itu, Mizan secara konsisten membuka Penerimaan Beasiswa Mizan setiap tahunnya. <br><br>

Awal tahun 2019 menjadi sebuah awalan bagi para mahasiswa yang tengah menyelesaikan studi akhirnya berupa skripsi, tesis, atau disertasi. Beasiswa Mizan 2019 dibuka untuk seluruh mahasiswa S1, S2, serta S3. Tak hanya mendapatkan beasiswa, hasil karya tulis yang terpilih juga memiliki kesempatan untuk diterbitkan. <br> <br>

<a href="https://himsiunsri.org/pendaftaran-beasiswa-mizan-2019/">klik disini</a> untuk info lebih lanjut

      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
          Djarum Foundation
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">Sejak 1984, Djarum Foundation terus konsisten dalam memberikan kontribusi terhadap dunia pendidikan di Indonesia. Langkah ini diawali kesadaran bahwa pendidikan merupakan salah satu upaya untuk meningkatkan kesejahteraan masyarakat dan bangsa dalam mewujudkan masa depan yang lebih baik.
<br><br>
Djarum Foundation turut berperan aktif dalam memajukan pendidikan di Indonesia melalui program beasiswa prestasi (merit based scholarship) yang dikenal sebagai Djarum Beasiswa Plus bagi mahasiswa berprestasi tinggi di Indonesia.Yang membedakan Djarum Beasiswa Plus dengan program beasiswa lain adalah, selain mendapatkan dana beasiswa selama satu tahun, Beswan Djarum (sebutan bagi penerima program Djarum Beasiswa Plus) juga mendapatkan berbagai macam pelatihan ketrampilan lunak atau soft skills guna mempersiapkan mereka menjadi calon pemimpin masa depan bangsa. Pelatihan ini meliputi Nation Building, Character Building, Leadership Development, Competition Challenges, serta International Exposure. <br><br>
<a href="https://himsiunsri.org/beasiswa-djarum-2019/">klik disini</a> untuk info lebih lanjut
      </div>
    </div>
  </div>
</div>
      
      <!-- /END THE FEATURETTES -->


      <!-- FOOTER -->
    </div><!-- /.container -->
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
