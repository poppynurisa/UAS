 <?php 
	require 'koneksi.php';
	session_start();
	//$nama = $_POST['nama'];
	$nim = $_POST['nim'];
	$password = $_POST['password'];
	$status = $_POST['status'];


	$result = mysqli_query($conn,"SELECT * FROM user where nim='$nim' and password ='$password'");

	$data	= mysqli_fetch_assoc($result);

 	if (mysqli_num_rows($result)>0){
 		//login
 		$_SESSION['login'] = true;
 		$_SESSION['nim'] = $nim;
 		$_SESSION['id'] = $data['id'];
 		$_SESSION['status'] = $data['status'];
 			
 			if ($data['status']=="dosen") {
 				header("location: admin.php");
 			}
 			else if ($data['status']=="mahasiswa") {
 				header("location: lapor.php");
 			}
 	}
 	
 	
 	else {
 		echo "lu ilegal bray!!!";
 		echo "<br>";
 		echo "<a href='formregister.php'>registrasi<a>";
 		echo " dulu aja bray. kali aja cocok ^^";
 		echo "<br>";
 		echo "<br>";
 		echo "<a href='login.php'> login?<a>";
 	}

?>