<?php 
session_start();
    if (!isset($_SESSION['login'])) {
    header("location: login.php");
    exit;  
  }
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Unsri Lapor</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->

<body>
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/unsri.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Layanan<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="kritik.php">kritik dan saran</a></li>
                    <li class="active"><a href="lapor.php">Lapor Fasilitas</a></li>
                  </ul>
                 <li><a href="beasiswa.php">Beasiswa</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php">Logout</a></li>
              </ul>
            </div>
        </div>
    </div>

      <div class="row featurette">
        <div class="col-md-5 col-md-push-2">
       <center>   
	<br><h2>FORM LAPORAN</h2>
	<br><br>
 	<form method="POST" action="actioncreat.php" enctype="multipart/form-data">
 		<input type="hidden" name="waktu">
 		nama	: 
		<input type="text" name="nama" placeholder="nama pelapor">
		<br>
		<br>
		gambar: <br><input type="file" name="gambar" placeholder="gambar" required id="gambar">
		<br><br>
		 deskripsi	:
		<textarea name="desk" rows="10" cols="50" placeholder="deskripsi"></textarea>
		<br><br>
	 	lokasi	:
		<input type="text" name="lokasi" placeholder="lokasi">
		<br><br>
		<input type="submit" name="submit">
 	</form>
 	</center>
 </div>
</div>

      <!-- FOOTER -->
    </div><!-- /.container -->
    <br><br><br>
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
