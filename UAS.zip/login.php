<?php 
	session_start();
	if (isset($_SESSION['login'])) {
		header("location : admin.php");
		exit;
	}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>login</title>
	<link rel="stylesheet" href="style.css">
	<form action="actionlogin.php" method="post">
</head>
<body> 


	<div class="box">
		<h2>Login</h2>
		<br><p style="background-color: white">untuk login sebagai admin <br>bapak bisa login menggunakan nip untuk nim dan passwordnya</p>
	<form>
		<div class="inputBox">
		<input type="number" name="nim" required=""> 
		<label>nim</label>
		</div>
		<div class="inputBox">
		<input type="password" name="password" required=""> 
		<label>password</label>
		</div>
		<input type="submit" name="submit" value="submit">
		<button> <a href="daftar.php">register</a></button>
	
	</form>
	</div>
	
</body>
</html>