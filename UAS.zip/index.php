<?php 

function CURL($url)
{
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  $result = curl_exec($curl);
  curl_close($curl);

  return json_decode($result, true);
}

  $result = CURL('https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=UCkLQJRQX9g7fT_E3zD6eCdw&key=AIzaSyCX0bK4oYpiYXU42S7JKHnreBYYMR-MHK4');


  $ypp = $result ['items'][0]['snippet']['thumbnails']['medium']['url'];
  $channelname = $result ['items'][0]['snippet']['title'];
  $subs = $result ['items'][0]['statistics']['subscriberCount'];

  //video terakhir
  $urlvideo = 'https://www.googleapis.com/youtube/v3/search?key=AIzaSyCX0bK4oYpiYXU42S7JKHnreBYYMR-MHK4&channelId=UCkLQJRQX9g7fT_E3zD6eCdw&maxResults=1&order=date&part=snippet';

  $result = CURL($urlvideo);

  $videoid = $result['items'][0]['id']['videoId'];

 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Unsri Lapor</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body>
<nav class="navbar navbar-fixed-top">
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/unsri.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Layanan<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="kritik.php">kritik dan saran</a></li>
                    <li><a href="lapor.php">Lapor Fasilitas</a></li>
                  </ul>
                 <li><a href="beasiswa.php">Beasiswa</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCkLQJRQX9g7fT_E3zD6eCdw">Youtube</a></li>
              </ul>
            </div>
        </div>

</nav>
    <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">

      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
        <li data-target="#myCarousel" data-slide-to="3"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img class="first-slide"  alt="First slide">
          <div class="container">
            <div class="carousel-caption">
              <img src="foto/unsri.png"  height="200px" width="200px" >
              <h1>Selamat Datang di Website Pengaduan UNSRI</h1>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="second-slide" src="foto/8.jpg" alt="Second slide">
          <div class="container">
            <div class="carousel-caption">
              <h2 style="color: white">untuk pengaduan silahkan klik Layanan pada navbar diatas</h2>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="third-slide" src="foto/2.jpg" alt="Third slide">
          <div class="container">
            <div class="carousel-caption">
              <h2 style="color: black">selain laporan fasilitas, anda juga bisa memberikan kritik dan saran</h2>
            </div>
          </div>
        </div>
        <div class="item">
          <img class="fourth-slide" src="foto/6.jpg" alt="fourth slide">
          <div class="container">
            <div class="carousel-caption">
              <h2 style="color: white">Ada info beasiswanya juga loh</h2>
            </div>
          </div>
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->



    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->    
<section>
    <div class="container">

      <!-- Three columns of text below the carousel -->
      <div class="row">
        <div class="col-lg-4">
          <img class="img-circle" src="foto/12.jpg" width="250px" height="250px">
          <h3>Pelantikan Pejabat Unsri 2019</h3>
          <p>Rektor Universitas Sriwijaya, Prof. Dr. Ir. H. Anis Saggaff, MSCE melantik 2 (dua) orang Wakil Dekan dan 2 (dua) Kepala Subbag di lingkungan Universitas Sriwijaya (Unsri). Pelantikan berlangsung di Lt. 2 Kantor Pusat Administrasi Unsri kampus Indralaya, 7 Mei 2019.</p>
          <p><a class="btn btn-default" href="http://www.unsri.ac.id/?act=info_detil&id=1025" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img class="img-circle" src="foto/13.jpg" width="250px" height="250px">
          <h3>Pemilihan Mawapres Unsri 2019</h3>
          <p>Utusan fakultas mempertahankan gagasannya di depan dewan juri untuk memperebutkan posisi juara satu dan menjadi utusan Universitas Sriwijaya (Unsri) di tingkat nasional. Adu kemampuan yang kejuaraannya ditentukan dari IPK, bobot karya ilmiah, bahasa, dan cara mempresentasikan hasil</p>
          <p><a class="btn btn-default" href="http://www.unsri.ac.id/?act=info_detil&id=1017" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->

        <div class="col-lg-4">
          <img class="img-circle" src="foto/3.jpg" width="250px" height="250px">
          <h3>Dua Orang Alumni Terbaik Pada Wisuda ke-141</h3>
          <p>ada acara itu Universitas Sriwijaya (Unsri) melepas 1.167 orang alumni yang terdiri dari sarjana Program Deploma, sarjana S1, S2, dan S3 dari 10 fakultas dan Program Pascasarjana terdiri dari Fakultas Ekonomi 128 orang, Fakultas Hukum 132 orang, Fakultas Teknik 120 orang</p>
          <p><a class="btn btn-default" href="http://www.unsri.ac.id/?act=info_detil&id=1021" role="button">View details &raquo;</a></p>
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->

</section>

<section class="social"  id="social" style="background-color: darkgrey">
  <div class="container">
    <div class="row">
      <div class="col text-center">
        <h2>Social Media</h2>
      </div>
    </div>
    <div class="row justify-content-center">

      <div class="col-md-5">
        <div class="row">
          <div class="col-md-4">
            <img src="<?= $ypp ?>" width="100" class="rounded-circle img-thumbnail">  
          </div>
          <div class="col-md-8">  
            <h5><?= $channelname ?></h5>
            <p><?= $subs ?> Subscribers.</p>
            <div class="g-ytsubscribe" data-channelid="UCkLQJRQX9g7fT_E3zD6eCdw" data-layout="default" data-count="default"></div>
          </div>
        </div><br>
        <div class="row mt-3 pb-3">
          <div class="col"> 
            <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?= $videoid?>?rel=0" allowfullscreen></iframe>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5"></div>
    </div>
  </div>
</section>  
      <!-- /END THE FEATURETTES -->


      <!-- FOOTER -->
    </div><!-- /.container -->
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
    <script src="https://apis.google.com/js/platform.js"></script>
  </body>
</html>
