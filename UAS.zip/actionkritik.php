<?php 
require 'koneksi.php';
	$pesan = $_POST['pesan'];
	
	

	$tambah = mysqli_query($conn,"INSERT INTO kritik VALUES(null,'$pesan',null)");

		if ($tambah>0) {
			echo "<center>";
			echo "kritik dan saran berhasil ditambahkan";
			echo "<br>";
			echo "klik";
			echo "<a href='kritik.php'>disini</a>";
		}
		else {
			echo "kritik dan saran gagal ditambahkan";
			echo "<br>";
			echo "klik ";
			echo "<a href='kritik.php'>disini</a>";
		

		}
	

 ?>

