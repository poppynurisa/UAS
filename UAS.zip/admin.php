<?php 
require 'koneksi.php';
  session_start();
  if (!isset($_SESSION['login'])) {
    header("location: login.php");
    exit;  
  } 
  if($_SESSION['status']!="dosen"){
  header('location:index.php');
  }
 
  $tampil = query ("SELECT * FROM blog");
  $metu = query ("SELECT * FROM kritik");
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Unsri Lapor</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="c.css" rel="stylesheet">
  </head>
<!-- NAVBAR
================================================== -->
  <body style="background-color: white">
<nav class="navbar navbar-fixed-top">
        <div class="navbar navbar-inverse navbar-static-top" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <img src="foto/unsri.png" width="55px" height="55px">
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Layanan<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="kritik.php">kritik dan saran</a></li>
                    <li class="active"><a href="lapor.php">Lapor Fasilitas</a></li>
                  </ul>
                 <li><a href="beasiswa.php">Beasiswa</a></li>
                </li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.youtube.com/channel/UCkLQJRQX9g7fT_E3zD6eCdw">Youtube</a></li>
              </ul>
            </div>
        </div>

</nav>

 <br><br><br><br>
        <div class="container">
<center>
<button><a href="lapor.php">Tambah</a></button>
<button><a href="logout.php">Logout</a></button>
<br><br>
    <h2>Selamat datang di Unsri Lapor!</h2>
  <br><br>
  </center>
</div>


        <div class="container">
<div class="row">
        <div class="col-lg-6">
<h2>Laporan Fasilitas</h2>
    <table border="1" cellpadding="0" cellspacing="0">
  <tr>
    <th>no</th>
    <th>nama pelapor</th>
    <th>gambar</th>
    <th>deskripsi</th>
    <th>lokasi</th>
    <th>waktu update</th>
    <th>opsi</th>
  </tr> 

<?php $i=1; ?>
<?php foreach ($tampil as $x ) : //foreach itu pengulangan pada array  ?> 
  <tr>
    <td><?= $i; ?></td>
    <td width="150"><?= $x["nama"] ?></td>
    <td><img src="img/<?= $x["gambar"];?>" width="70"></td>
    <td width="500"><?= $x["desk"];?></td>
    <td width="130"><?= $x["lokasi"];  ?></td>
    <td><?= $x["waktu"];  ?></td>
    <td>
      <center><button><a href="ubah.php?id=<?= $x["id"]?>">ubah</a></button><br><br><button><a href="hapus.php?id=<?= $x["id"]?>" onclick =" return confirm ('yakin bray mau dihapus?');">hapus</a></button></center>
    </td>
  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>
</div>

        <div class="col-lg-6">
          <h2>Kritik Dan Saran</h2>
    <table border="1" cellpadding="0" cellspacing="0">
  <tr>
    <th>no</th>
    <th>isi pesan</th>
    <th>waktu update</th>
    <th>opsi</th>
  </tr> 

<?php $i=1; ?>
<?php foreach ($metu as $x ) : //foreach itu pengulangan pada array  ?> 
  <tr>
    <td><?= $i; ?></td>
    <td width="150"><?= $x["pesan"] ?></td>
    <td><?= $x["waktu"];  ?></td>
    <td>
      <center><button><a href="hapus.php?id=<?= $x["id"]?>" onclick =" return confirm ('yakin bray mau dihapus?');">hapus</a></button></center>
    </td>
  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>
</div>
</div>
</div>

<br><br>
        <!-- FOOTER -->
    </div><!-- /.container -->
     <div class="panel-footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Poppy, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrapnjquery/jquery.min.js"></script>
    <script src="bootstrapnjquery/js/bootstrap.min.js"></script>
    <script src="boot/assets/js/docs.min.js"></script>
  </body>
</html>
